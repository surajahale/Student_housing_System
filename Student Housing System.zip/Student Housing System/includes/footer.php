<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - Student Housing System - Developed by <a href="">Group No: 9</a>
</footer>